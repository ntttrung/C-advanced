 gcc busdemo.c jval.c jrb.c dllist.c -w
./a.out
